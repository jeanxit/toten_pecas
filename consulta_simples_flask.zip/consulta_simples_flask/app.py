from flask import Flask, request, render_template, send_file, session, redirect, url_for
import pandas as pd
import requests
from io import BytesIO

app = Flask(__name__)
app.secret_key = "supersecretkey"  # necessário para usar sessão

@app.route("/", methods=["GET", "POST"])
def index():
    resultados = []
    erro = None

    if request.method == "POST":
        cnpjs = []

        if request.form.get("cnpj"):
            cnpj_digitado = request.form["cnpj"].strip()
            cnpjs.append(cnpj_digitado)

        file = request.files.get("file")
        if file and file.filename.endswith(".xlsx"):
            df = pd.read_excel(file)
            if "CNPJ" not in df.columns:
                erro = "A planilha precisa ter a coluna 'CNPJ'"
                return render_template("index.html", error=erro)
            cnpjs.extend(df["CNPJ"].dropna().astype(str).tolist())

        cnpjs = list(set([c.strip() for c in cnpjs if c.strip()]))

        print(f"[INFO] Total de CNPJs para consultar: {len(cnpjs)}")

        for cnpj in cnpjs:
            print(f"[INFO] Consultando CNPJ: {cnpj}")
            try:
                r = requests.get(f"https://brasilapi.com.br/api/cnpj/v1/{cnpj}")
                if r.status_code == 200:
                    dados = r.json()
                    opcao = dados.get("opcao_pelo_simples", "erro")
                    resultados.append({"CNPJ": cnpj, "opcao_pelo_simples": opcao})
                else:
                    resultados.append({"CNPJ": cnpj, "opcao_pelo_simples": "erro"})
            except Exception as e:
                resultados.append({"CNPJ": cnpj, "opcao_pelo_simples": "erro"})

        # salvar na sessão para exportação
        session["resultados"] = resultados
        return render_template("index.html", resultados=resultados)

    return render_template("index.html")

@app.route("/exportar")
def exportar():
    resultados = session.get("resultados", [])
    if not resultados:
        return redirect(url_for("index"))

    df_result = pd.DataFrame(resultados)
    output = BytesIO()
    df_result.to_excel(output, index=False)
    output.seek(0)
    return send_file(output, download_name="resultado_simples.xlsx", as_attachment=True)

if __name__ == "__main__":
    app.run(debug=True, port=9900)
